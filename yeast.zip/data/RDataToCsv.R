# Turns the .RData files into csvs to be used for MLWSE

for(k in 1:10){
  load(paste0("data_", k, ".RData"))
  trainX <- rbind(data$train, data$val)
  trainY <- rbind(data$trainActual, data$valActual)
  for(i in seq(ncol(trainY))){
    trainY[, i] <- as.numeric(trainY[, i] == data$labels[[i]][2])
  }
  testX <- data$test
  
  write.csv(trainX, file = paste0("trainX_", k, ".csv"), row.names = FALSE)
  write.csv(trainY, file = paste0("trainY_", k, ".csv"), row.names = FALSE)
  write.csv(testX, file = paste0("testX_", k, ".csv"), row.names = FALSE)
  
  write.csv(trainX[1:nrow(data$train), ], file = paste0("trainXWithoutVal_", k, ".csv"), row.names = FALSE)
  write.csv(trainY[1:nrow(data$train), ], file = paste0("trainYWithoutVal_", k, ".csv"), row.names = FALSE)
  write.csv(trainX[-(1:nrow(data$train)), ], file = paste0("trainXVal_", k, ".csv"), row.names = FALSE)
  write.csv(trainY[-(1:nrow(data$train)), ], file = paste0("trainYVal_", k, ".csv"), row.names = FALSE)
}
