# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:10){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("test_", i,".csv"), header = FALSE)
  colnames(pred) <- colnames(data$test)
  pred <- sapply(pred, function(x) pmin(1, pmax(0, x)))
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#       logLikTest   hamTest   accTest f1Test
#  [1,]  -5.905128 0.1924939 0.1694915    NaN
#  [2,]  -5.714966 0.1901822 0.1934156    NaN
#  [3,]  -5.526307 0.1849593 0.2154472    NaN
#  [4,]  -5.503641 0.1868596 0.1940928    NaN
#  [5,]  -5.126510 0.1769277 0.2217573    NaN
#  [6,]  -5.620710 0.1781305 0.2057613    NaN
#  [7,]  -5.776497 0.1908665 0.2049180    NaN
#  [8,]  -5.359590 0.1904762 0.2032520    NaN
#  [9,]  -5.176480 0.1841335 0.1967213    NaN
# [10,]  -5.413932 0.1846981 0.2092050    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
# logLikTest    hamTest    accTest     f1Test 
# -5.5123759  0.1859728  0.2014062        NaN
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#  logLikTest     hamTest     accTest      f1Test 
# 0.226855766 0.004786958 0.012954563          NA 