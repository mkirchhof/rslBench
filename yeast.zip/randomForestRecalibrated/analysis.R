# Plotting the calibration of the initial random forest predictions

# Dependencies:
source("rsl.R")
library(RColorBrewer)
cols <- brewer.pal(10, "Set3")

# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    probList <- .preprocessInhProbs(rsl, probs)
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

calTrain <- list()
calValTest <- list()
for(i in 1:10){
  load(paste0("../recalibratedData/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Transform to 0-1 form 
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  data$trainActual <- .crispToProabilisticData(rsl, data$trainActual)
  data$trainActual <- data$trainActual[, seq(2, ncol(data$trainActual), 2)]
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  data$valActual <- .crispToProabilisticData(rsl, data$valActual)
  data$valActual <- data$valActual[, seq(2, ncol(data$valActual), 2)]
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  data$testActual <- .crispToProabilisticData(rsl, data$testActual)
  data$testActual <- data$testActual[, seq(2, ncol(data$testActual), 2)]
  
  # categorize into 10% bins
  data$train <- round(data$train, 1)
  data$val <- round(data$val, 1)
  data$test <- round(data$test, 1)
  
  # Calculate calibration
  calTrain[[i]] <- tapply(unlist(data$trainActual), unlist(data$train), mean)
  calValTest[[i]] <- tapply(unlist(rbind(data$valActual, data$testActual)), 
                            unlist(rbind(data$val, data$test)), mean)
}

pdf("calibration.pdf", width = 5, height = 10)
par(mfrow = c(2, 1), mar = c(5.1, 5.1, 1, 1))
plot(NA, xlim = c(0, 1), ylim = c(0, 1), ylab = "Relative amount of true labels", xlab = "Prediction", sub = "Train")
lines(x = c(0, 1), y = c(0, 1), lty = 2)
for(i in seq(length(calTrain))){
  points(x = as.numeric(names(calTrain[[i]])), y = calTrain[[i]], type = "b", col = cols[i])
}
plot(NA, xlim = c(0, 1), ylim = c(0, 1), ylab = "Relative amount of true labels", xlab = "Prediction", sub = "Val+Test")
lines(x = c(0, 1), y = c(0, 1), lty = 2)
for(i in seq(length(calValTest))){
  points(x = as.numeric(names(calValTest[[i]])), y = calValTest[[i]], type = "b", col = cols[i])
}
dev.off()