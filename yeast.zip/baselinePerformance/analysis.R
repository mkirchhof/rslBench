# Evaluates the performance of the baseline classifiers without any rsl


# Dependencies:
source("rsl.R")
library(microbenchmark)


# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  cat("Predicting on train...\n")
  predTrainMarg <- predict(rsl, train)
  logLTrainMarg <- median(.labelwiseLogLikelihood(predTrainMarg, trainActual))
  predTrainMarg <- .probabilisticToCrispData(rsl, predTrainMarg)
  accTrainMarg <- accuracy(predTrainMarg, trainActual)
  hamTrainMarg <- hammingLoss(predTrainMarg, trainActual)
  likTrainMarg <- .avgLogLikelihood(rsl, train, trainActual)
  #likTrainMarg <- NA
  try({predTrainJoint <- predict(rsl, train, type = "joint", method = "approximate")
  predTrainJoint <- .probabilisticToCrispData(rsl, predTrainJoint)
  accTrainJoint <- accuracy(predTrainJoint, trainActual)})
  
  cat("Predicting on val...\n")
  predValMarg <- predict(rsl, val)
  logLValMarg <- median(.labelwiseLogLikelihood(predValMarg, valActual))
  predValMarg <- .probabilisticToCrispData(rsl, predValMarg)
  accValMarg <- accuracy(predValMarg, valActual)
  hamValMarg <- hammingLoss(predValMarg, valActual)
  likValMarg <- .avgLogLikelihood(rsl, val, valActual)
  #likValMarg <- NA
  try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  predValJoint <- .probabilisticToCrispData(rsl, predValJoint)
  accValJoint <- accuracy(predValJoint, valActual)})
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestMarg <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestMarg <- median(.labelwiseLogLikelihood(predTestMarg, testActual))
  predTestMarg <- .probabilisticToCrispData(rsl, predTestMarg)
  accTestMarg <- accuracy(predTestMarg, testActual)
  hamTestMarg <- hammingLoss(predTestMarg, testActual)
  likTestMarg <- .avgLogLikelihood(rsl, test, testActual)
  # likTestMarg <- NA
  try({predTestJoint <- predict(rsl, test, type = "joint", method = "approximate")
  predTestJoint <- .probabilisticToCrispData(rsl, predTestJoint)
  accTestJoint <- accuracy(predTestJoint, testActual)})
  
  return(list(accTrain = accTrainMarg, hamTrain = hamTrainMarg, logLikTrain = likTrainMarg, labelwiseLogLTrain = logLTrainMarg, accTrainMPE = accTrainJoint,
              accVal = accValMarg, hamVal = hamValMarg, logLikVal = likValMarg, labelwiseLogLVal = logLValMarg, accValMPE = accValJoint,
              accTest = accTestMarg, hamTest = hamTestMarg, logLikTest = likTestMarg, labelwiseLogLTest = logLTestMarg, accTestMPE = accTestJoint,
              avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


set.seed(25112020)
for(i in 1:10){
  cat(i, "...\n")
  load(paste0("../data/data_", i, ".RData"))
  
  rsl <- .buildRSL(data$labels, list())
  # Change colnames of xyzActual stuff
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  
  res <- .evalPerformance(rsl, data$train, data$trainActual,
                          data$val, data$valActual,
                          data$test, data$testActual)
  save(res, file = paste0(i, "_res.RData"))
}


allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#        accTrain  hamTrain logLikTrain labelwiseLogLTrain accTrainMPE    accVal    hamVal logLikVal labelwiseLogLVal accValMPE   accTest   hamTest logLikTest labelwiseLogLTest accTestMPE avgPredTime
#  [1,] 0.1774110 0.1895307   -5.769991          -5.769991   0.1774110 0.1487603 0.1874262 -5.608645        -5.608645 0.1487603 0.1313559 0.1918886  -6.232789         -6.232789  0.1313559     3180287
#  [2,] 0.1727884 0.1883083   -5.687379          -5.687379   0.1727884 0.1701245 0.1858328 -5.630632        -5.630632 0.1701245 0.1893004 0.1887125  -5.878292         -5.878292  0.1893004     3188693
#  [3,] 0.1709845 0.1877498   -5.740572          -5.740572   0.1709845 0.1576763 0.1965027 -5.742798        -5.742798 0.1576763 0.1747967 0.1872822  -5.686126         -5.686126  0.1747967     3189761
#  [4,] 0.1775026 0.1869748   -5.786091          -5.786091   0.1775026 0.1528926 0.1886068 -6.007495        -6.007495 0.1528926 0.1729958 0.1913803  -5.619112         -5.619112  0.1729958     3197917
#  [5,] 0.1652893 0.1910419   -5.854269          -5.854269   0.1652893 0.2190083 0.1806375 -5.824728        -5.824728 0.2190083 0.1841004 0.1829050  -5.576407         -5.576407  0.1841004     3184157
#  [6,] 0.1717538 0.1899712   -5.743877          -5.743877   0.1717538 0.1452282 0.1905750 -5.464007        -5.464007 0.1452282 0.1440329 0.1863610  -5.899099         -5.899099  0.1440329     3167953
#  [7,] 0.1677019 0.1884428   -5.771753          -5.771753   0.1677019 0.1576763 0.1849437 -5.465316        -5.465316 0.1576763 0.1803279 0.1917447  -5.984749         -5.984749  0.1803279     3191448
#  [8,] 0.1715026 0.1889711   -5.775982          -5.775982   0.1715026 0.2074689 0.1858328 -5.965398        -5.965398 0.2074689 0.1869919 0.1907666  -5.656450         -5.656450  0.1869919     3198101
#  [9,] 0.1697723 0.1886276   -5.797194          -5.797194   0.1697723 0.1701245 0.1923533 -5.563933        -5.563933 0.1701245 0.1885246 0.1835480  -5.554540         -5.554540  0.1885246     3208952
# [10,] 0.1652893 0.1900826   -5.757918          -5.757918   0.1652893 0.2107438 0.1883117 -5.933949        -5.933949 0.2107438 0.1841004 0.1835027  -5.628405         -5.628405  0.1841004     3191352

nFolds <- nrow(allData)
apply(allData, 2, mean)
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal   labelwiseLogLVal 
# 1.709995e-01       1.889701e-01      -5.768503e+00      -5.768503e+00       1.709995e-01       1.739704e-01       1.881023e-01      -5.720690e+00      -5.720690e+00 
#    accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
# 1.739704e-01       1.736527e-01       1.878092e-01      -5.771597e+00      -5.771597e+00       1.736527e-01       3.189862e+06 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal   labelwiseLogLVal 
# 3.853740e-03       1.087898e-03       3.869494e-02       3.869494e-02       3.853740e-03       2.504479e-02       3.928821e-03       1.837778e-01       1.837778e-01 
#    accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
# 2.504479e-02       1.793717e-02       3.252967e-03       1.979330e-01       1.979330e-01       1.793717e-02       9.983970e+03 