# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:10){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("test_", i,".csv"), header = FALSE)
  colnames(pred) <- colnames(data$test)
  pred <- sapply(pred, function(x) pmin(1, pmax(0, x)))
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#       logLikTest   hamTest   accTest f1Test
#  [1,]  -6.081894 0.1949153 0.1483051    NaN
#  [2,]  -5.931421 0.1960611 0.2016461    NaN
#  [3,]  -5.450762 0.1901858 0.2154472    NaN
#  [4,]  -5.654191 0.1901748 0.2109705    NaN
#  [5,]  -5.380629 0.1799163 0.1841004    NaN
#  [6,]  -5.738320 0.1860670 0.1893004    NaN
#  [7,]  -5.947054 0.1940867 0.2090164    NaN
#  [8,]  -5.464628 0.1959930 0.1788618    NaN
#  [9,]  -5.371606 0.1864754 0.1885246    NaN
# [10,]  -5.572261 0.1930663 0.2008368    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
# logLikTest    hamTest    accTest     f1Test 
# -5.6592766  0.1906942  0.1927009        NaN 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#  logLikTest     hamTest     accTest      f1Test 
# 0.230648079 0.004721877 0.017821759          NA 