accValMAP <- numeric(10)
load(paste0("../data/data_1.RData"))
colnames(data$valActual) <- paste0("L", 1:14)

for(i in 2:10){
  load(paste0("1_", i * 10, "_rsl.RData"))
  
  predValMAP <- predict(rsl, data$val, type = "joint")
  predValMAP <- .probabilisticToCrispData(rsl, predValMAP)
  accValMAP[i] <- accuracy(predValMAP, data$valActual)
  print(accValMAP)
}
save(accValMAP, file = "jointPredAcc.RData")