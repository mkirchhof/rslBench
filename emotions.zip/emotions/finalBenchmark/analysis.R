# This script summarizes the final benchmark results


# Dependencies
source("rsl.R")

# Build design matrix and result matrix
A <- matrix(ncol = 3, nrow = 50)
Y <- matrix(ncol = 11, nrow = 50)
# Folds are the intercepts
colnames(A) <- c("nRules", "it", "fold")
colnames(Y) <- c("accTrain", "hamTrain", "logLikTrain", "accVal", "hamVal", "F1Val", "logLVal", "accTest", "hamTest", "F1Test", "logLTest")


f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}


# Read data
todo <- expand.grid(rules = 20, folds = 1:10, it = 1:5)
for(folds in seq(nrow(todo))){
  fold <- todo[folds, "folds"]
  nRules <- todo[folds, "rules"]
  it <- todo[folds, "it"]
  
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_rsl.RData"))
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_res.RData"))
  load(paste0("../data/data_", fold,".RData"))
  
  # Calculate F1 for val and test:
  predVal <- .probabilisticToCrispData(rsl, res$predValMarg)
  colnames(predVal) <- colnames(data$valActual)
  f1Val <- f1macro(predVal, data$valActual)
  predTest <- .probabilisticToCrispData(rsl, res$predTestMarg)
  colnames(predTest) <- colnames(data$testActual)
  f1Test <- f1macro(predTest, data$testActual)
  
  A[folds, ] <- c(nRules, it, fold)
  Y[folds, ] <- c(res[["accTrainMPE"]], res[["hamTrain"]], res[["logLikTrain"]],
                  res[["accValMPE"]], res[["hamVal"]], f1Val, res[["logLikVal"]],
                  res[["accTestMPE"]], res[["hamTest"]], f1Test, res[["logLikTest"]])
}
data <- as.data.frame(cbind(A, Y))

plot(x = jitter(data$logLVal), y = jitter(data$accVal), pch = data$fold)


# Choose best hyperparameter per fold
nFolds <- max(todo$folds)
bestData <- matrix(ncol = 14, nrow = nFolds)
colnames(bestData) <- colnames(data)
for(i in seq(nFolds)){
  best <- which.max(data$accVal[data$fold == i])
  bestData[i, ] <- unlist(data[data$fold == i & data$it == best, ])
}


# Report results
apply(bestData, 2, mean)
     # nRules          it        fold    accTrain    hamTrain logLikTrain      accVal      hamVal       F1Val     logLVal     accTest     hamTest      F1Test    logLTest 
#  20.0000000   2.7000000   5.5000000   0.3513755   0.1815858  -1.8018348   0.3389831   0.1810734   0.6650155  -1.9206354   0.3482313   0.1823904   0.6746258  -1.8391661 
apply(bestData, 2, sd) * (nFolds - 1) / nFolds
     # nRules          it        fold    accTrain    hamTrain logLikTrain      accVal      hamVal       F1Val     logLVal     accTest     hamTest      F1Test    logLTest 
# 0.000000000 1.126499001 2.724885319 0.014691107 0.005031774 0.077016800 0.031344478 0.018311753 0.028617647 0.241009925 0.066763475 0.021812645 0.048083000 0.273141391 