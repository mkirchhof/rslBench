# This script fits a quadratic model to the hyperparameter experiments to choose
# an optimal hyperparameter

# Build design matrix and result matrix
A <- matrix(ncol = 2, nrow = 20)
Y <- matrix(ncol = 3, nrow = 20)
# Folds are the intercepts
colnames(A) <- c("nRules", "reg")
colnames(Y) <- c("accuracy", "hamming", "logLoss")

# Do the same for train data (to see if we are overfitting)
Y2 <- Y


# Read data
for(i in 1:10){
  load(paste0("../emotionsHardHyperParamTuning/1_", i * 10 ,"_res.RData"))
  A[i, ] <- c(i * 10, 0)
  Y[i, ] <- c(res[["accValMPE"]], res[["hamVal"]], res[["logLikVal"]])
  Y2[i, ] <- c(res[["accTrainMPE"]], res[["hamTrain"]], res[["logLikTrain"]])
}
for(i in 1:10){
  load(paste0("../emotionsAdaptiveHyperParamTuning/1_", i * 10 ,"_res.RData"))
  A[i + 10, ] <- c(i * 10, 1)
  Y[i + 10, ] <- c(res[["accValMPE"]], res[["hamVal"]], res[["logLikVal"]])
  Y2[i + 10, ] <- c(res[["accTrainMPE"]], res[["hamTrain"]], res[["logLikTrain"]])
}
data <- as.data.frame(cbind(A, Y))
data$reg <- factor(data$reg, levels = c(0, 1), labels = c("hard", "adapt"))


# Plot raw data
load("../baselinePerformance/1_res.RData")
baseline <- c("accuracy" = res[["accValMPE"]], "hamming" = res[["hamVal"]], 
              "logLoss" = res[["logLikVal"]])
pdf(paste0("performance.pdf"), height = 12, width = 6)
par(mfrow = c(3, 1), mar = c(4, 4, 1, 1))
plot(x = data$nRules, y = data$accuracy, col = data$reg, 
     ylim = range(c(data$accuracy, baseline["accuracy"])),
     xlab = "Number of Rules", ylab = "Accuracy")
abline(h = baseline["accuracy"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)

plot(x = data$nRules, y = 1 - data$hamming, col = data$reg, 
     ylim = range(c(1 - data$hamming, 1 - baseline["hamming"])),
     xlab = "Number of Rules", ylab = "Hamming Accuracy")
abline(h = 1 - baseline["hamming"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)

plot(x = data$nRules, y = data$logLoss, col = data$reg, 
     ylim = range(c(data$logLoss, baseline["logLoss"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["logLoss"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
dev.off()
# Obvious gain in log Likelihood and small gain in accuracy. Hamming Accuracy 
# does not get worse, but also not considerably better. nRules = 40 seems to be
# the best hyperparameter, and no clear winner in hard vs adaptive regularization.
# Overall, this is expected behaviour: We optimized for log Likelihood, hence it's
# so good, and the base classifier already optimized for hamming accuracy, so 
# there's not much to win there (as we provided the same, full input data to all
# baseline classifiers). Accuracy rises, probably because pRSL models the joint
# distribution as opposed to the baselines, which model marginals.


# Fit quadratic models
# Accuracy model
modL <- lm("accuracy ~ nRules*reg + I(nRules^2)*reg", data = data)
plot(modL)
# Looks good; maybe a bit much leverage of 1 and 11, but still ok
plot(x = data$nRules, y = data$accuracy, col = data$reg, 
     ylim = range(c(data$accuracy, baseline["accuracy"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["accuracy"], lty = 2,  col = 4)
points(y = modL$fitted.values[1:10], x = seq(10, 100, 10), type = "l")
points(y = modL$fitted.values[11:20], x = seq(10, 100, 10), type = "l", col = 2)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
# Model suggests that hard and adaptive regularizer have different optima, 
# but let's see if the parameters are significant anyways
summary(modL)
# Call:
#   lm(formula = "accuracy ~ nRules*reg + I(nRules^2)*reg", data = data)
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.029765 -0.014513 -0.001058  0.012624  0.035500 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)           2.139e-01  2.455e-02   8.714 4.99e-07 ***
#   nRules               -1.997e-04  1.025e-03  -0.195    0.848    
# regadapt             -3.657e-02  3.472e-02  -1.053    0.310    
# I(nRules^2)           4.070e-06  9.083e-06   0.448    0.661    
# nRules:regadapt       1.983e-03  1.450e-03   1.367    0.193    
# regadapt:I(nRules^2) -1.925e-05  1.285e-05  -1.499    0.156    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02087 on 14 degrees of freedom
# Multiple R-squared:  0.2404,	Adjusted R-squared:  -0.03088 
# F-statistic: 0.8862 on 5 and 14 DF,  p-value: 0.5158

# None of the parameters is really significant, suggesting that the model does
# not really care

# Hamming loss model
modL <- lm("hamming ~ nRules*reg + I(nRules^2)*reg", data = data)
plot(modL)
# looks ok, maybe a bit light tailed
plot(x = data$nRules, y = data$hamming, col = data$reg, 
     ylim = range(c(data$hamming, baseline["hamming"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["hamming"], lty = 2,  col = 4)
points(y = modL$fitted.values[1:10], x = seq(10, 100, 10), type = "l")
points(y = modL$fitted.values[11:20], x = seq(10, 100, 10), type = "l", col = 2)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
# Model suggests that hard and adaptive regularizer have different optima, 
# but let's see if the parameters are significant anyways
summary(modL)
# Call:
#   lm(formula = "hamming ~ nRules*reg + I(nRules^2)*reg", data = data)
# 
# Residuals:
#   Min         1Q     Median         3Q        Max 
# -0.0050499 -0.0012712  0.0001413  0.0008523  0.0055061 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)           1.771e-01  3.579e-03  49.498   <2e-16 ***
#   nRules                1.098e-04  1.495e-04   0.735    0.475    
# regadapt              8.683e-03  5.061e-03   1.716    0.108    
# I(nRules^2)          -5.367e-07  1.324e-06  -0.405    0.691    
# nRules:regadapt      -3.154e-04  2.114e-04  -1.492    0.158    
# regadapt:I(nRules^2)  2.381e-06  1.873e-06   1.272    0.224    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.003043 on 14 degrees of freedom
# Multiple R-squared:  0.2452,	Adjusted R-squared:  -0.02439 
# F-statistic: 0.9095 on 5 and 14 DF,  p-value: 0.5024

# Nothing is really significant; model does not care.


# LogLoss model
modL <- lm("logLoss ~ nRules*reg + I(nRules^2)*reg", data = data)
plot(modL)
# Points 1 and 11 (the two with nRules = 10) seem to have a high leverage and
# destroy the model a bit. As these two points obviously have the worst performance
# anyways, we will exclude them from our optimization model:
modL <- lm("logLoss ~ nRules*reg + I(nRules^2)*reg", data = data[-c(1, 11), ])
plot(modL)
# Looks good.
plot(x = data$nRules, y = data$logLoss, col = data$reg, 
     ylim = range(c(data$logLoss, baseline["logLoss"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["logLoss"], lty = 2,  col = 4)
points(y = modL$fitted.values[1:9], x = seq(20, 100, 10), type = "l")
points(y = modL$fitted.values[10:18], x = seq(20, 100, 10), type = "l", col = 2)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
# Looks like a valid fit
summary(modL)
# Call:
#   lm(formula = "logLoss ~ nRules*reg + I(nRules^2)*reg", data = data[-c(1, 
#                                                                         11), ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.045687 -0.026258 -0.007569  0.016649  0.120438 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)          -3.998e+00  8.490e-02 -47.094 5.49e-15 ***
#   nRules                1.156e-02  3.156e-03   3.662  0.00325 ** 
#   regadapt             -1.243e-01  1.201e-01  -1.035  0.32094    
# I(nRules^2)          -9.553e-05  2.584e-05  -3.697  0.00305 ** 
#   nRules:regadapt       2.098e-03  4.463e-03   0.470  0.64672    
# regadapt:I(nRules^2)  1.024e-06  3.655e-05   0.028  0.97811    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.04535 on 12 degrees of freedom
# Multiple R-squared:  0.7808,	Adjusted R-squared:  0.6895 
# F-statistic:  8.55 on 5 and 12 DF,  p-value: 0.00119

# Appearently the regularizer choice does not matter while the nRules do. 
# So let's fit a final model without the regularizer
modL <- lm("logLoss ~ nRules + I(nRules^2)", data = data[-c(1, 11), ])
plot(modL)
# Looks good
plot(x = data$nRules, y = data$logLoss, col = data$reg, 
     ylim = range(c(data$logLoss, baseline["logLoss"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["logLoss"], lty = 2,  col = 4)
points(y = modL$fitted.values[1:9], x = seq(20, 100, 10), type = "l")
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
optimize(function(n) -predict(modL, newdata = data.frame(nRules = n)), interval = c(20, 100))
# $minimum
# [1] 66.32639
# 
# $objective
# 1 
# 3.642547 

# Suggests using 66 rules, regardless of which regularizer.
