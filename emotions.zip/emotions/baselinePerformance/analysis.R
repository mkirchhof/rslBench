# Evaluates the performance of the baseline classifiers without any rsl


# Dependencies:
source("rsl.R")
library(microbenchmark)


# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  cat("Predicting on train...\n")
  predTrainMarg <- predict(rsl, train)
  logLTrainMarg <- median(.labelwiseLogLikelihood(predTrainMarg, trainActual))
  predTrainMarg <- .probabilisticToCrispData(rsl, predTrainMarg)
  accTrainMarg <- accuracy(predTrainMarg, trainActual)
  hamTrainMarg <- hammingLoss(predTrainMarg, trainActual)
  likTrainMarg <- .avgLogLikelihood(rsl, train, trainActual)
  #likTrainMarg <- NA
  try({predTrainJoint <- predict(rsl, train, type = "joint", method = "approximate")
  predTrainJoint <- .probabilisticToCrispData(rsl, predTrainJoint)
  accTrainJoint <- accuracy(predTrainJoint, trainActual)})
  
  cat("Predicting on val...\n")
  predValMarg <- predict(rsl, val)
  logLValMarg <- median(.labelwiseLogLikelihood(predValMarg, valActual))
  predValMarg <- .probabilisticToCrispData(rsl, predValMarg)
  accValMarg <- accuracy(predValMarg, valActual)
  hamValMarg <- hammingLoss(predValMarg, valActual)
  likValMarg <- .avgLogLikelihood(rsl, val, valActual)
  #likValMarg <- NA
  try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  predValJoint <- .probabilisticToCrispData(rsl, predValJoint)
  accValJoint <- accuracy(predValJoint, valActual)})
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestMarg <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestMarg <- median(.labelwiseLogLikelihood(predTestMarg, testActual))
  predTestMarg <- .probabilisticToCrispData(rsl, predTestMarg)
  accTestMarg <- accuracy(predTestMarg, testActual)
  hamTestMarg <- hammingLoss(predTestMarg, testActual)
  likTestMarg <- .avgLogLikelihood(rsl, test, testActual)
  # likTestMarg <- NA
  try({predTestJoint <- predict(rsl, test, type = "joint", method = "approximate")
  predTestJoint <- .probabilisticToCrispData(rsl, predTestJoint)
  accTestJoint <- accuracy(predTestJoint, testActual)})
  
  return(list(accTrain = accTrainMarg, hamTrain = hamTrainMarg, logLikTrain = likTrainMarg, labelwiseLogLTrain = logLTrainMarg, accTrainMPE = accTrainJoint,
              accVal = accValMarg, hamVal = hamValMarg, logLikVal = likValMarg, labelwiseLogLVal = logLValMarg, accValMPE = accValJoint,
              accTest = accTestMarg, hamTest = hamTestMarg, logLikTest = likTestMarg, labelwiseLogLTest = logLTestMarg, accTestMPE = accTestJoint,
              avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


set.seed(25112020)
for(i in 1:10){
  cat(i, "...\n")
  load(paste0("../data/data_", i, ".RData"))
  
  rsl <- .buildRSL(data$labels, list())
  # Change colnames of xyzActual stuff
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  
  res <- .evalPerformance(rsl, data$train, data$trainActual,
                          data$val, data$valActual,
                          data$test, data$testActual)
  save(res, file = paste0(i, "_res.RData"))
}


allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#        accTrain  hamTrain logLikTrain labelwiseLogLTrain accTrainMPE    accVal    hamVal logLikVal labelwiseLogLVal accValMPE   accTest   hamTest logLikTest labelwiseLogLTest accTestMPE avgPredTime
#  [1,] 0.3033473 0.1886332   -2.397079          -2.397079   0.3033473 0.3898305 0.1751412 -2.114065        -2.114065 0.3898305 0.3392857 0.1666667  -2.397144         -2.397144  0.3392857     2021564
#  [2,] 0.3284211 0.1796491   -2.313161          -2.313161   0.3284211 0.3220339 0.1977401 -2.588263        -2.588263 0.3220339 0.2372881 0.1920904  -2.389774         -2.389774  0.2372881     3399325
#  [3,] 0.3192389 0.1807611   -2.322676          -2.322676   0.3192389 0.3220339 0.1694915 -2.238451        -2.238451 0.3220339 0.3114754 0.1967213  -2.508641         -2.508641  0.3114754     1896616
#  [4,] 0.3199153 0.1825565   -2.328474          -2.328474   0.3199153 0.3220339 0.1723164 -2.353026        -2.353026 0.3220339 0.2903226 0.1908602  -2.445339         -2.445339  0.2903226     1901347
#  [5,] 0.3107822 0.1860465   -2.379415          -2.379415   0.3107822 0.3050847 0.2005650 -2.390582        -2.390582 0.3050847 0.4098361 0.1557377  -2.350324         -2.350324  0.4098361     2127169
#  [6,] 0.3138075 0.1851464   -2.367390          -2.367390   0.3138075 0.2372881 0.1864407 -2.472112        -2.472112 0.2372881 0.3392857 0.1547619  -2.158745         -2.158745  0.3392857     1937500
#  [7,] 0.3262712 0.1836158   -2.286520          -2.286520   0.3262712 0.2542373 0.1977401 -2.538923        -2.538923 0.2542373 0.3548387 0.1586022  -2.277265         -2.277265  0.3548387     2178011
#  [8,] 0.3156780 0.1850282   -2.365221          -2.365221   0.3156780 0.3898305 0.1468927 -2.154230        -2.154230 0.3898305 0.3387097 0.1774194  -2.467681         -2.467681  0.3387097     3004056
#  [9,] 0.3430962 0.1722455   -2.202695          -2.202695   0.3430962 0.2542373 0.1892655 -2.508376        -2.508376 0.2542373 0.2142857 0.2202381  -2.696786         -2.696786  0.2142857     2066668
# [10,] 0.3172269 0.1841737   -2.366394          -2.366394   0.3172269 0.2881356 0.1694915 -2.259097        -2.259097 0.2881356 0.3793103 0.1781609  -2.169287         -2.169287  0.3793103     2153336

nFolds <- nrow(allData)
apply(allData, 2, mean)
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal 
# 3.197785e-01       1.827856e-01      -2.332902e+00      -2.332902e+00       3.197785e-01       3.084746e-01       1.805085e-01      -2.361713e+00 
# labelwiseLogLVal          accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
#    -2.361713e+00       3.084746e-01       3.214638e-01       1.791259e-01      -2.386099e+00      -2.386099e+00       3.214638e-01       2.268559e+06 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal 
# 9.816789e-03       4.059765e-03       5.131386e-02       5.131386e-02       9.816789e-03       4.759061e-02       1.522832e-02       1.492292e-01 
# labelwiseLogLVal          accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
#     1.492292e-01       4.759061e-02       5.436928e-02       1.903640e-02       1.450168e-01       1.450168e-01       5.436928e-02       4.594614e+05 