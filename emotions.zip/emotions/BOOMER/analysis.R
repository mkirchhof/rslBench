# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:10){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("./", i, "/pred.csv"), header = TRUE)
  # Remove ground truth labels
  pred <- pred[, (ncol(pred)/2 + 1):ncol(pred)]
  colnames(pred) <- colnames(data$test)
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#       logLikTest   hamTest   accTest f1Test
#  [1,]        -23 0.1755952 0.3750000    NaN
#  [2,]        -23 0.1807910 0.2881356    NaN
#  [3,]        -23 0.2213115 0.2459016    NaN
#  [4,]        -23 0.2069892 0.2258065    NaN
#  [5,]        -23 0.1666667 0.4098361    NaN
#  [6,]        -23 0.1398810 0.4285714    NaN
#  [7,]        -23 0.1586022 0.3225806    NaN
#  [8,]        -23 0.1801075 0.3870968    NaN
#  [9,]        -23 0.2232143 0.1964286    NaN
# [10,]        -23 0.1810345 0.3793103    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
#  logLikTest     hamTest     accTest      f1Test 
# -23.0000000   0.1834193   0.3258668         NaN 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
# logLikTest    hamTest    accTest     f1Test 
# 0.00000000 0.02409713 0.07422419         NA 