# This script recalibrates the data

# Dependencies
source("rsl.R")


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    probList <- .preprocessInhProbs(rsl, probs)
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


for(i in 1:10){
  load(paste0("../data/data_", i, ".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Transform actuals to 0-1 form 
  input <- data$trainActual
  colnames(input) <- .getAllLabelNodes(rsl)
  input <- .crispToProabilisticData(rsl, input)
  input <- input[, seq(2, ncol(input), 2)]
  
  for(j in seq(ncol(data$train))){
    # Fit logistic regression
    dat <- data.frame(x = data$train[, j], y = input[, j])
    mod <- glm(y ~ x, data = dat, family = binomial)
    
    # Recalibrate data
    data$train[, j] <- predict(mod, data.frame(x = data$train[, j]), type = "response")
    data$val[, j] <- predict(mod, data.frame(x = data$val[, j]), type = "response")
    data$test[, j] <- predict(mod, data.frame(x = data$test[, j]), type = "response")
  }
  
  save(data, file = paste0("data_", i, ".RData"))
}