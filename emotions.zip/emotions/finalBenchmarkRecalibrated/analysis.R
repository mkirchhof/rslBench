# This script summarizes the final benchmark results


# Dependencies
source("rsl.R")

# Build design matrix and result matrix
A <- matrix(ncol = 3, nrow = 10)
Y <- matrix(ncol = 8, nrow = 10)
# Folds are the intercepts
colnames(A) <- c("nRules", "it", "fold")
colnames(Y) <- c("accVal", "hamVal", "F1Val", "logLVal", "accTest", "hamTest", "F1Test", "logLTest")


f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}


# Read data
todo <- expand.grid(rules = 20, folds = 1:10, it = 1)
for(folds in seq(nrow(todo))){
  fold <- todo[folds, "folds"]
  nRules <- todo[folds, "rules"]
  it <- todo[folds, "it"]
  
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_rsl.RData"))
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_res.RData"))
  load(paste0("../data/data_", fold,".RData"))
  
  # Calculate F1 for val and test:
  predVal <- .probabilisticToCrispData(rsl, res$predValMarg)
  colnames(predVal) <- colnames(data$valActual)
  f1Val <- f1macro(predVal, data$valActual)
  predTest <- .probabilisticToCrispData(rsl, res$predTestMarg)
  colnames(predTest) <- colnames(data$testActual)
  f1Test <- f1macro(predTest, data$testActual)
  
  A[folds, ] <- c(nRules, it, fold)
  Y[folds, ] <- c(res[["accValMPE"]], res[["hamVal"]], f1Val, res[["logLikVal"]],
                  res[["accTestMPE"]], res[["hamTest"]], f1Test, res[["logLikTest"]])
}
data <- as.data.frame(cbind(A, Y))

plot(x = jitter(data$logLVal), y = jitter(data$accVal), pch = data$fold)


# Choose best hyperparameter per fold
nFolds <- max(todo$folds)
bestData <- matrix(ncol = 11, nrow = nFolds)
colnames(bestData) <- colnames(data)
for(i in seq(nFolds)){
  best <- which.max(data$accVal[data$fold == i])
  bestData[i, ] <- unlist(data[data$fold == i & data$it == best, ])
}


# Report results
apply(bestData, 2, mean)
#     nRules         it       fold     accVal     hamVal      F1Val    logLVal    accTest    hamTest     F1Test   logLTest 
# 20.0000000  1.0000000  5.5000000  0.3033898  0.1813559  0.6677046 -1.9312058  0.3284284  0.1908313  0.6588312 -1.9041094 
apply(bestData, 2, sd) * (nFolds - 1) / nFolds
#     nRules         it       fold     accVal     hamVal      F1Val    logLVal    accTest    hamTest     F1Test   logLTest 
# 0.00000000 0.00000000 2.72488532 0.03171349 0.01788919 0.02896686 0.15691659 0.07289139 0.02281249 0.04385858 0.23031929 