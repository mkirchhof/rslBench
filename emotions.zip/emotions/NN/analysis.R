# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:10){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("test_", i,".csv"), header = FALSE)
  colnames(pred) <- colnames(data$test)
  pred <- sapply(pred, function(x) pmin(1, pmax(0, x)))
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#       logLikTest   hamTest   accTest f1Test
#  [1,]  -1.959698 0.1726190 0.3928571    NaN
#  [2,]  -2.014475 0.1723164 0.3050847    NaN
#  [3,]  -2.372916 0.2295082 0.1967213    NaN
#  [4,]  -2.077464 0.1908602 0.3064516    NaN
#  [5,]  -1.878931 0.1666667 0.3770492    NaN
#  [6,]  -1.656502 0.1369048 0.3928571    NaN
#  [7,]  -2.449224 0.1881720 0.2258065    NaN
#  [8,]  -1.919296 0.1801075 0.3225806    NaN
#  [9,]  -2.636052 0.2202381 0.1785714    NaN
# [10,]  -2.085921 0.1752874 0.3965517    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
# logLikTest    hamTest    accTest     f1Test 
# -2.1050479  0.1832680  0.3094531        NaN 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
# logLikTest    hamTest    accTest     f1Test 
# 0.26655436 0.02384728 0.07536124         NA 