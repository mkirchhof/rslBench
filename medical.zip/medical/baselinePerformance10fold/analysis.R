# Evaluates the performance of the baseline classifiers without any rsl


# Dependencies:
source("rsl.R")
library(microbenchmark)


# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  cat("Predicting on train...\n")
  predTrainRSL <- predict(rsl, train)
  logLTrainRSL <- mean(.labelwiseLogLikelihood(predTrainRSL, trainActual))
  predTrainRSL <- .probabilisticToCrispData(rsl, predTrainRSL)
  accTrainRSL <- accuracy(predTrainRSL, trainActual)
  hamTrainRSL <- hammingLoss(predTrainRSL, trainActual)
  likTrainRSL <- .avgLogLikelihood(rsl, train, trainActual)
  # likTrainRSL <- NA
  # cat("Predicting train2...\n")
  # predTrainMAP <- predict(rsl, train, type = "joint")
  # predTrainMAP <- .probabilisticToCrispData(rsl, predTrainMAP)
  # accTrainMAP <- accuracy(predTrainMAP, trainActual)
  
  cat("Predicting on val...\n")
  predValRSL <- predict(rsl, val)
  logLValRSL <- mean(.labelwiseLogLikelihood(predValRSL, valActual))
  predValRSL <- .probabilisticToCrispData(rsl, predValRSL)
  accValRSL <- accuracy(predValRSL, valActual)
  hamValRSL <- hammingLoss(predValRSL, valActual)
  likValRSL <- .avgLogLikelihood(rsl, val, valActual)
  # likValRSL <- NA
  # predValMAP <- predict(rsl, val, type = "joint")
  # predValMAP <- .probabilisticToCrispData(rsl, predValMAP)
  # accValMAP <- accuracy(predValMAP, valActual)
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestRSL <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestRSL <- mean(.labelwiseLogLikelihood(predTestRSL, testActual))
  predTestRSL <- .probabilisticToCrispData(rsl, predTestRSL)
  accTestRSL <- accuracy(predTestRSL, testActual)
  hamTestRSL <- hammingLoss(predTestRSL, testActual)
  likTestRSL <- .avgLogLikelihood(rsl, test, testActual)
  # likTestRSL <- NA
  # predTestMAP <- predict(rsl, test, type = "joint")
  # predTestMAP <- .probabilisticToCrispData(rsl, predTestMAP)
  # accTestMAP <- accuracy(predTestMAP, testActual)
  
  return(list(accTrain = accTrainRSL, hamTrain = hamTrainRSL, logLikTrain = likTrainRSL, labelwiseLogLTrain = logLTrainRSL,
              accVal = accValRSL, hamVal = hamValRSL, logLikVal = likValRSL, labelwiseLogLVal = logLValRSL,
              accTest = accTestRSL, hamTest = hamTestRSL, logLikTest = likTestRSL, labelwiseLogLTest = logLTestRSL,
              avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


set.seed(25112020)
for(i in 1:10){
  cat(i, "...\n")
  load(paste0("../data/data_", i, ".RData"))
  
  rsl <- .buildRSL(data$labels, list())
  # Change colnames of xyzActual stuff
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  
  res <- .evalPerformance(rsl, data$train, data$trainActual,
                          data$val, data$valActual,
                          data$test, data$testActual)
  save(res, file = paste0(i, "_res.RData"))
}


allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

do.call(rbind, allRes)

#       accTrain  hamTrain   logLikTrain labelwiseLogLTrain accVal    hamVal     logLikVal labelwiseLogLVal accTest   hamTest    logLikTest labelwiseLogLTest avgPredTime
#  [1,] 0.444586  0.01508846 -2.164129   -2.164129          0.377551  0.01791383 -2.041037 -2.041037        0.3789474 0.01707602 -1.948     -1.948            6837171    
#  [2,] 0.440613  0.01546757 -2.169088   -2.169088          0.371134  0.01603666 -1.740112 -1.740112        0.4387755 0.01587302 -2.157326  -2.157326         6842973    
#  [3,] 0.4269231 0.0160114  -2.152767   -2.152767          0.4639175 0.0139748  -1.748262 -1.748262        0.4851485 0.01320132 -1.893394  -1.893394         6805688    
#  [4,] 0.4196429 0.01604308 -2.210667   -2.210667          0.3917526 0.01718213 -1.872894 -1.872894        0.5051546 0.01443299 -1.793885  -1.793885         6819235    
#  [5,] 0.4464286 0.01547619 -2.159429   -2.159429          0.443299  0.01328751 -1.796379 -1.796379        0.4226804 0.01603666 -2.059032  -2.059032         6862855    
#  [6,] 0.4265645 0.01569462 -2.162169   -2.162169          0.4123711 0.01534937 -1.862795 -1.862795        0.4081633 0.01723356 -1.927772  -1.927772         6805047    
#  [7,] 0.4234694 0.01575964 -2.218648   -2.218648          0.443299  0.01557847 -1.997099 -1.997099        0.4536082 0.01557847 -1.911691  -1.911691         6859502    
#  [8,] 0.440051  0.01547619 -2.220039   -2.220039          0.3917526 0.01809851 -1.830187 -1.830187        0.443299  0.01466208 -1.802853  -1.802853         6871435    
#  [9,] 0.4494238 0.0152511  -2.195748   -2.195748          0.4329897 0.01603666 -1.980411 -1.980411        0.44      0.01511111 -1.891887  -1.891887         6822968    
# [10,] 0.4291188 0.01580815 -2.172864   -2.172864          0.3402062 0.01809851 -2.228715 -2.228715        0.4489796 0.01496599 -1.952925  -1.952925         6854517    