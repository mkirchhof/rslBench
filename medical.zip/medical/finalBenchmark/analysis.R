# This script summarizes the final benchmark results


# Dependencies
source("rsl.R")

# Build design matrix and result matrix
A <- matrix(ncol = 3, nrow = 25)
Y <- matrix(ncol = 11, nrow = 25)
# Folds are the intercepts
colnames(A) <- c("nRules", "it", "fold")
colnames(Y) <- c("accTrain", "hamTrain", "logLikTrain", "accVal", "hamVal", "F1Val", "logLVal", "accTest", "hamTest", "F1Test", "logLTest")


f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}


# Read data
todo <- expand.grid(rules = 48, folds = 1:5, it = 1:5)
for(folds in seq(nrow(todo))){
  fold <- todo[folds, "folds"]
  nRules <- todo[folds, "rules"]
  it <- todo[folds, "it"]
  
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_rsl.RData"))
  load(paste0("../finalBenchmark/", fold, "_", nRules ,"_", it, "_res.RData"))
  load(paste0("../data/data_", fold,".RData"))
  
  # Calculate F1 for val and test:
  predVal <- .probabilisticToCrispData(rsl, res$predValMarg)
  colnames(predVal) <- colnames(data$valActual)
  f1Val <- f1macro(predVal, data$valActual)
  predTest <- .probabilisticToCrispData(rsl, res$predTestMarg)
  colnames(predTest) <- colnames(data$testActual)
  f1Test <- f1macro(predTest, data$testActual)
  
  A[folds, ] <- c(nRules, it, fold)
  Y[folds, ] <- c(res[["accTrainMPE"]], res[["hamTrain"]], res[["labelwiseLogLTrain"]],
                  res[["accValMPE"]], res[["hamVal"]], f1Val, res[["labelwiseLogLVal"]],
                  res[["accTestMPE"]], res[["hamTest"]], f1Test, res[["labelwiseLogLTest"]])
}
data <- as.data.frame(cbind(A, Y))

plot(x = jitter(data$logLVal), y = jitter(data$accVal), pch = data$fold)


# Choose best hyperparameter per fold
nFolds <- max(todo$folds)
bestData <- matrix(ncol = 14, nrow = nFolds)
colnames(bestData) <- colnames(data)
for(i in seq(nFolds)){
  best <- which.max(data$accVal[data$fold == i])
  bestData[i, ] <- unlist(data[data$fold == i & data$it == best, ])
}


# Report results
apply(bestData, 2, mean)
#      nRules          it        fold    accTrain    hamTrain logLikTrain      accVal      hamVal       F1Val     logLVal     accTest     hamTest      F1Test    logLTest 
# 48.00000000  3.20000000  3.00000000  0.49799467  0.01535556 -1.58694457  0.49690215  0.01539194         NaN -1.62536005  0.49070766  0.01545695         NaN -1.56512538 
apply(bestData, 2, sd) * (nFolds - 1) / nFolds
#       nRules           it         fold     accTrain     hamTrain  logLikTrain       accVal       hamVal        F1Val      logLVal      accTest      hamTest       F1Test     logLTest 
# 0.0000000000 1.6395121226 1.2649110641 0.0194269159 0.0007909368 0.0221498630 0.0266676590 0.0008817351           NA 0.0514809377 0.0313281698 0.0011355414           NA 0.1202216983 