# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:5){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("test_", i,".csv"), header = FALSE)
  colnames(pred) <- colnames(data$test)
  pred <- sapply(pred, function(x) pmin(1, pmax(0, x)))
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 5, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 5, byrow = TRUE)
colnames(allData) <- names(res)

#      logLikTest     hamTest   accTest f1Test
# [1,] -0.7353754 0.012763533 0.5948718    NaN
# [2,] -0.6099433 0.009977324 0.6428571    NaN
# [3,] -1.0150592 0.013131313 0.5656566    NaN
# [4,] -0.7800441 0.012535613 0.5948718    NaN
# [5,] -0.6103344 0.010882016 0.6649485    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
#  logLikTest     hamTest     accTest      f1Test 
# -0.75015129  0.01185796  0.61264115         NaN 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#  logLikTest     hamTest     accTest      f1Test 
# 0.132963225 0.001087379 0.032219525          NA 