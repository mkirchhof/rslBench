# This script fits a quadratic model to the hyperparameter experiments to choose
# an optimal hyperparameter

# Build design matrix and result matrix
A <- matrix(ncol = 2, nrow = 15)
Y <- matrix(ncol = 3, nrow = 15)
# Folds are the intercepts
colnames(A) <- c("nRules", "it")
colnames(Y) <- c("accuracy", "hamming", "logLoss")


# Read data
todo <- expand.grid(rules = c(25, 50, 75, 100, 125), folds = 1, it = 1:3)
for(folds in seq(nrow(todo))){
  fold <- todo[folds, "folds"]
  nRules <- todo[folds, "rules"]
  it <- todo[folds, "it"]
  
  load(paste0("../medicalAdaptiveHyperParamParallel/", fold, "_", nRules ,"_", it, "_res.RData"))
  A[folds, ] <- c(nRules, it)
  Y[folds, ] <- c(res[["accValMPE"]], res[["hamVal"]], res[["labelwiseLogLVal"]])
}
data <- as.data.frame(cbind(A, Y))


# Plot raw data
load("../baselinePerformance/1_res.RData")
baseline <- c("accuracy" = res[["accVal"]], "hamming" = res[["hamVal"]], 
              "logLoss" = res[["labelwiseLogLVal"]])
pdf(paste0("performance.pdf"), height = 12, width = 6)
par(mfrow = c(3, 1), mar = c(4, 4, 1, 1))
plot(x = data$nRules, y = data$accuracy, 
     ylim = range(c(data$accuracy, baseline["accuracy"])),
     xlab = "Number of Rules", ylab = "Accuracy")
abline(h = baseline["accuracy"], lty = 2,  col = 4)

plot(x = data$nRules, y = 1 - data$hamming,
     ylim = range(c(1 - data$hamming, 1 - baseline["hamming"])),
     xlab = "Number of Rules", ylab = "Hamming Accuracy")
abline(h = 1 - baseline["hamming"], lty = 2,  col = 4)

plot(x = data$nRules, y = data$logLoss, 
     ylim = range(c(data$logLoss, baseline["logLoss"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["logLoss"], lty = 2,  col = 4)
dev.off()


# Choose best hyperparameters:
modL <- lm("accuracy ~ nRules + I(nRules^2) + I(nRules^3)", data = data)
par(mfrow = c(1, 1))
plot(modL)
# Slight heteroscedasticity
opt <- optimize(function(n) -predict(modL, newdata = data.frame(nRules = n)), range(data$nRules))$minimum
rounded <- predict(modL, newdata = data.frame(nRules = c(floor(opt), ceiling(opt))))
if(rounded[1] >= rounded[2]){
  opt <- floor(opt)
} else {
  opt <- ceiling(opt)
}

pdf("tuning.pdf", width = 8, height  = 6)
par(mar = c(4, 4, 1, 1) + 0.1)
plot(x = data$nRules, y = data$accuracy,
     ylim = range(c(data$accuracy, baseline["accuracy"])),
     xlab = "Number of Rules", ylab = "Accuracy", xaxt = "n")
axis(1, at = unique(data$nRules))
abline(h = baseline["accuracy"], lty = 2,  col = 4)
points(y = predict(modL, newdata = data.frame(nRules = seq(range(data$nRules)[1], range(data$nRules)[2]))), 
       x = seq(range(data$nRules)[1], range(data$nRules)[2]), type = "l")
text(y = predict(modL, newdata = data.frame(nRules = opt)), 
     x = opt, labels = opt, pos = 3, col = 2)
points(y = predict(modL, newdata = data.frame(nRules = opt)), x = opt, pch = 8, col = 2)
legend("bottomleft", legend = c("Raw Results", "Smoothed Results", "Optimum", "Base Classifier"),
       col = c(1, 1, 2, 4), pch = c(1, NA, 8, NA), lty = c(NA, 1, NA, 2))
dev.off()