# Evaluates the performance of the baseline classifiers without any rsl


# Dependencies:
source("rsl.R")
library(microbenchmark)


# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  # cat("Predicting on train...\n")
  # predTrainMarg <- predict(rsl, train)
  # logLTrainMarg <- mean(.labelwiseLogLikelihood(predTrainMarg, trainActual))
  # predTrainMarg <- .probabilisticToCrispData(rsl, predTrainMarg)
  # accTrainMarg <- accuracy(predTrainMarg, trainActual)
  # hamTrainMarg <- hammingLoss(predTrainMarg, trainActual)
  # # likTrainMarg <- .avgLogLikelihood(rsl, train, trainActual)
  # likTrainMarg <- NA
  # # cat("Predicting train2...\n")
  # try({predTrainJoint <- predict(rsl, train, type = "joint", method = "approximate")
  # predTrainJoint <- .probabilisticToCrispData(rsl, predTrainJoint)
  # accTrainJoint <- accuracy(predTrainJoint, trainActual)})
  
  cat("Predicting on val...\n")
  predValMarg <- predict(rsl, val)
  logLValMarg <- median(.labelwiseLogLikelihood(predValMarg, valActual))
  predValMarg <- .probabilisticToCrispData(rsl, predValMarg)
  accValMarg <- accuracy(predValMarg, valActual)
  hamValMarg <- hammingLoss(predValMarg, valActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, valActual)
  likValMarg <- NA
  try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  predValJoint <- .probabilisticToCrispData(rsl, predValJoint)
  accValJoint <- accuracy(predValJoint, valActual)})
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestMarg <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestMarg <- median(.labelwiseLogLikelihood(predTestMarg, testActual))
  predTestMarg <- .probabilisticToCrispData(rsl, predTestMarg)
  accTestMarg <- accuracy(predTestMarg, testActual)
  hamTestMarg <- hammingLoss(predTestMarg, testActual)
  # likTestMarg <- .avgLogLikelihood(rsl, test, testActual)
  likTestMarg <- NA
  try({predTestJoint <- predict(rsl, test, type = "joint", method = "approximate")
  predTestJoint <- .probabilisticToCrispData(rsl, predTestJoint)
  accTestJoint <- accuracy(predTestJoint, testActual)})
  
  return(list(#accTrain = accTrainMarg, hamTrain = hamTrainMarg, logLikTrain = likTrainMarg, labelwiseLogLTrain = logLTrainMarg, accTrainMPE = accTrainJoint,
    accVal = accValMarg, hamVal = hamValMarg, logLikVal = likValMarg, labelwiseLogLVal = logLValMarg, accValMPE = accValJoint,
    accTest = accTestMarg, hamTest = hamTestMarg, logLikTest = likTestMarg, labelwiseLogLTest = logLTestMarg, accTestMPE = accTestJoint,
    avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


set.seed(25112020)
for(i in 1:5){
  cat(i, "...\n")
  load(paste0("../data/data_", i, ".RData"))
  
  rsl <- .buildRSL(data$labels, list())
  # Change colnames of xyzActual stuff
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  
  res <- .evalPerformance(rsl, data$train, data$trainActual,
                          data$val, data$valActual,
                          data$test, data$testActual)
  save(res, file = paste0(i, "_res.RData"))
}


allRes <- list()
for(nRules in seq(1, 5, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 5, byrow = TRUE)
colnames(allData) <- names(res)

#         accVal     hamVal logLikVal labelwiseLogLVal accValMPE   accTest    hamTest logLikTest labelwiseLogLTest accTestMPE avgPredTime
# [1,] 0.4102564 0.01538462        NA        -1.632243 0.4102564 0.3589744 0.01800570         NA         -1.608092  0.3589744     7764815
# [2,] 0.3282051 0.01846154        NA        -1.713138 0.3282051 0.3877551 0.01655329         NA         -1.472788  0.3877551     7652543
# [3,] 0.3846154 0.01800570        NA        -1.591202 0.3846154 0.3888889 0.01638608         NA         -1.555349  0.3888889     7651113
# [4,] 0.3692308 0.01663818        NA        -1.561918 0.3692308 0.3641026 0.01743590         NA         -1.766447  0.3641026     7588639
# [5,] 0.3877551 0.01689342        NA        -1.647553 0.3877551 0.4278351 0.01615120         NA         -1.519175  0.4278351     7644252

nFolds <- nrow(allData)
apply(allData, 2, mean)
#       accVal            hamVal         logLikVal  labelwiseLogLVal         accValMPE           accTest           hamTest        logLikTest 
# 3.760126e-01      1.707669e-02                NA     -1.629211e+00      3.760126e-01      3.855112e-01      1.690643e-02                NA 
# labelwiseLogLTest        accTestMPE       avgPredTime 
#     -1.584370e+00      3.855112e-01      7.660272e+06 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#       accVal            hamVal         logLikVal  labelwiseLogLVal         accValMPE           accTest           hamTest        logLikTest 
# 2.438386e-02      9.691116e-04                NA      4.623813e-02      2.438386e-02      2.180013e-02      6.266820e-04                NA 
# labelwiseLogLTest        accTestMPE       avgPredTime 
#      9.056089e-02      2.180013e-02      5.131979e+04 