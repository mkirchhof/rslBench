# Get the ID that SLURM hands over to the script as argument
folds <- as.integer(Sys.getenv("PBS_ARRAYID"))
if(is.na(folds)){
  folds <- 1:10
}
cat("ID = ", paste(folds, collapse = ", "), "\n")

todo <- expand.grid(rules = seq(10, 100, 10), folds = 1:10)
fold <- todo[folds, "folds"]
nRules <- todo[folds, "rules"]

# Dependencies:
source("rsl.R")
library(microbenchmark)

# And the simData_k.RData have to be located in the directory

# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  cat("Predicting on train...\n")
  predTrainRSL <- predict(rsl, train)
  logLTrainRSL <- mean(.labelwiseLogLikelihood(predTrainRSL, trainActual))
  predTrainRSL <- .probabilisticToCrispData(rsl, predTrainRSL)
  accTrainRSL <- accuracy(predTrainRSL, trainActual)
  hamTrainRSL <- hammingLoss(predTrainRSL, trainActual)
  # likTrainRSL <- .avgLogLikelihood(rsl, train, trainActual)
  likTrainRSL <- NA
  # cat("Predicting train2...\n")
  # predTrainMAP <- predict(rsl, train, type = "joint")
  # predTrainMAP <- .probabilisticToCrispData(rsl, predTrainMAP)
  # accTrainMAP <- accuracy(predTrainMAP, trainActual)
  
  cat("Predicting on val...\n")
  predValRSL <- predict(rsl, val)
  logLValRSL <- mean(.labelwiseLogLikelihood(predValRSL, valActual))
  predValRSL <- .probabilisticToCrispData(rsl, predValRSL)
  accValRSL <- accuracy(predValRSL, valActual)
  hamValRSL <- hammingLoss(predValRSL, valActual)
  # likValRSL <- .avgLogLikelihood(rsl, val, valActual)
  likValRSL <- NA
  # predValMAP <- predict(rsl, val, type = "joint")
  # predValMAP <- .probabilisticToCrispData(rsl, predValMAP)
  # accValMAP <- accuracy(predValMAP, valActual)
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestRSL <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestRSL <- mean(.labelwiseLogLikelihood(predTestRSL, testActual))
  predTestRSL <- .probabilisticToCrispData(rsl, predTestRSL)
  accTestRSL <- accuracy(predTestRSL, testActual)
  hamTestRSL <- hammingLoss(predTestRSL, testActual)
  # likTestRSL <- .avgLogLikelihood(rsl, test, testActual)
  likTestRSL <- NA
  # predTestMAP <- predict(rsl, test, type = "joint")
  # predTestMAP <- .probabilisticToCrispData(rsl, predTestMAP)
  # accTestMAP <- accuracy(predTestMAP, testActual)
  
  return(list(accTrain = accTrainRSL, hamTrain = hamTrainRSL, logLikTrain = likTrainRSL, labelwiseLogLTrain = logLTrainRSL,
              accVal = accValRSL, hamVal = hamValRSL, logLikVal = likValRSL, labelwiseLogLVal = logLValRSL,
              accTest = accTestRSL, hamTest = hamTestRSL, logLikTest = likTestRSL, labelwiseLogLTest = logLTestRSL,
              avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

# Main:
# Learn an rsl
# load an object called data containing all important data
load(paste0("../data/data_", fold, ".RData"))
set.seed(22122020)
cat(fold, ":", nRules, "\n")
rsl <- .buildRSL(data$labels, list())
# Change colnames of xyzActual stuff
colnames(data$trainActual) <- .getAllLabelNodes(rsl)
colnames(data$valActual) <- .getAllLabelNodes(rsl)
colnames(data$testActual) <- .getAllLabelNodes(rsl)
rsl <- learnRules(rsl, data$train, data$trainActual, nRules = nRules,
                  method = "noisyor", batchsize = 20, reg = "none", lambda = 5,
                  maxLabelsPerRule = 5, alphaReg = 0.025, betaReg = 0.5, regDecay = 0.98)

# evaluate and save
save(rsl, file = paste0(fold, "_", nRules, "_rsl.RData"))
res <- .evalPerformance(rsl, data$train, data$trainActual,
                        data$val, data$valActual,
                        data$test, data$testActual)
save(res, file = paste0(fold, "_", nRules, "_res.RData"))
