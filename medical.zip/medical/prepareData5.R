# Create the base learners (Binary Relevance) for YEAST dataset.

# Base learners used in past approaches:
# Random Forest (Discovering and Exploiting Deterministic...)
# Logistic Regression (Bayes Optimal Multilabel Classification...)

# Validation:
# 10-fold CV (Discovering and Exploiting...)
# 3-fold CV (Bayes Optimal Multilabel Classification)

# We will use random forest and 10-fold CV.

# Dependencies:
library(mldr.datasets)
library(mldr)
library(ranger)
#library(mlr3)
#library(mlr3learners)
# Also, be sure to download the medical dataset in MULAN format to the working directory

# Load data:
set.seed(123)
medical <- mldr("medical")
# Change some column names, because R does not like "-" in column names
colnames(medical$dataset) <- gsub("-", "_", colnames(medical$dataset))
attr(medical$attributes, "names") <- gsub("-", "_", attr(medical$attributes, "names"))
rownames(medical$labels) <- gsub("-", "_", rownames(medical$labels))
data <- iterative.stratification.kfolds(medical, k = 5)

# Gather information about the labels
labelInfo <- lapply(medical$dataset[, medical$labels$index], function(x) sort(unique(x)))
for(i in seq(along = labelInfo)){
  labelInfo[[i]] <- paste0(names(labelInfo)[[i]], "_", labelInfo[[i]])
}

# For each kfold: Use training data to learn and validate a random forest for
# each label, then report results on the test data.
set.seed(20082020)
for(fold in seq(length(data))){
  cat("fold =", fold, "... ")
  # Split train into train and validation (80/10), and prepare the test dataset
  valIndex <- sample(nrow(data[[fold]]$train$dataset), 
                     size = floor(1 / 4 * nrow(data[[fold]]$train$dataset)))
  allLabels <- rownames(data[[fold]]$train$labels)
  for(label in seq(along = allLabels)){
    cat("label =", label, "... ")
    varIndex <- c(data[[fold]]$train$attributesIndexes, 
                  data[[fold]]$train$labels$index[label])
    varIndex <- varIndex[!colnames(data[[fold]]$train$dataset)[varIndex] %in% c(".labelcount", ".SCUMBLE")]
    labelName <- allLabels[label]
    train <- data[[fold]]$train$dataset[-valIndex, varIndex]
    val <- data[[fold]]$train$dataset[valIndex, varIndex]
    fullTrain <- data[[fold]]$train$dataset[, varIndex]
    test <- data[[fold]]$test$dataset[, varIndex]
    # transform label to factor because mlr
    train[, labelName] <- factor(train[, labelName], levels = c("0", "1"))
    val[, labelName] <- factor(val[, labelName], levels = c("0", "1"))
    fullTrain[, labelName] <- factor(fullTrain[, labelName], levels = c("0", "1"))
    test[, labelName] <- factor(test[, labelName], levels = c("0", "1"))
    
    # Rename attributes or else mlr will not comply
    newNames <- paste0("A_", seq(ncol(train)))
    #newNames[length(newNames)] <- labelName
    colnames(train) <- newNames
    colnames(val) <- newNames
    colnames(fullTrain) <- newNames
    colnames(test) <- newNames
    
    if(length(unique(train[, ncol(train)])) > 1){
      rf <- ranger(data = train, dependent.variable.name = newNames[length(newNames)], probability = TRUE)
      inTrain <- rf$predictions[, "1"]
      inVal <- predict(rf, data = val)$predictions[, "1"]
      inTest <- predict(rf, data = test)$predictions[, "1"]
      
      # Save predictions and metrics
      data[[fold]]$train$prob[[labelName]] <- numeric(nrow(fullTrain))
      data[[fold]]$train$prob[[labelName]][valIndex] <- inVal
      data[[fold]]$train$prob[[labelName]][-valIndex] <- inTrain
      data[[fold]]$test$prob[[labelName]] <- inTest
    } else {
      # we only have observations of one kind in the dataset. mlr will crash,
      # but a random forest will always give out that label, so we do it by hand
      
      prob <- ifelse(unique(unique(train[, ncol(train)])) == "1", 0.999, 0.001)
      data[[fold]]$train$prob[[labelName]] <- rep(prob, nrow(fullTrain))
      data[[fold]]$test$prob[[labelName]] <- rep(prob, nrow(test))
    }
  }
  
  # Change lists to data.frames
  data[[fold]]$train$prob <- as.data.frame(data[[fold]]$train$prob)
  data[[fold]]$test$prob <- as.data.frame(data[[fold]]$test$prob)
  
  # Build the data object to output
  outData <- list()
  outData$train <- data[[fold]]$train$prob[-valIndex, ]
  outData$trainActual <- data[[fold]]$train$dataset[-valIndex, allLabels]
  outData$val <- data[[fold]]$train$prob[valIndex, ]
  outData$valActual <- data[[fold]]$train$dataset[valIndex, allLabels]
  outData$test <- data[[fold]]$test$prob
  outData$testActual <- data[[fold]]$test$dataset[, allLabels]
  
  # Rename the stuff from 0/1 to unique labels
  colnames(outData$train) <- paste0(colnames(outData$train), "_1")
  colnames(outData$val) <- paste0(colnames(outData$val), "_1")
  colnames(outData$test) <- paste0(colnames(outData$test), "_1")
  for(l in seq(along = allLabels)){
    outData$trainActual[, l] <- paste0(colnames(outData$trainActual)[l], "_", outData$trainActual[, l])
    outData$valActual[, l] <- paste0(colnames(outData$valActual)[l], "_", outData$valActual[, l])
    outData$testActual[, l] <- paste0(colnames(outData$testActual)[l], "_", outData$testActual[, l])
  }
  
  # Attach label information to make it easier to construct the rsls
  outData$labels <- labelInfo
  
  # Save to harddrive
  otherData <- data # save reference, so that we can call the output object data, too
  data <- outData
  save(data, file = paste0("data_", fold, ".RData"))
  data <- otherData
  
  cat("\n")
}

