# This script fits a quadratic model to the hyperparameter experiments to choose
# an optimal hyperparameter

# Build design matrix and result matrix
A <- matrix(ncol = 2, nrow = 20)
Y <- matrix(ncol = 3, nrow = 20)
# Folds are the intercepts
colnames(A) <- c("nRules", "reg")
colnames(Y) <- c("accuracy", "hamming", "logLoss")


# Read data
for(i in 1:10){
  load(paste0("../medicalHardHyperParamTuning/1_", i * 10 ,"_res.RData"))
  A[i, ] <- c(i * 10, 0)
  Y[i, ] <- c(res[["accTrain"]], res[["hamTrain"]], res[["labelwiseLogLTrain"]])
}
for(i in 1:10){
  load(paste0("../medicalAdaptiveHyperParamTuning/1_", i * 10 ,"_res.RData"))
  A[i + 10, ] <- c(i * 10, 1)
  Y[i + 10, ] <- c(res[["accTrain"]], res[["hamTrain"]], res[["labelwiseLogLTrain"]])
}
data <- as.data.frame(cbind(A, Y))
data$reg <- factor(data$reg, levels = c(0, 1), labels = c("hard", "adapt"))


# Plot raw data
load("../baselinePerformance/1_res.RData")
baseline <- c("accuracy" = res[["accTrain"]], "hamming" = res[["hamTrain"]], 
              "logLoss" = res[["labelwiseLogLTrain"]])
pdf(paste0("performance.pdf"), height = 12, width = 6)
par(mfrow = c(3, 1), mar = c(4, 4, 1, 1))
plot(x = data$nRules, y = data$accuracy, col = data$reg, 
     ylim = range(c(data$accuracy, baseline["accuracy"])),
     xlab = "Number of Rules", ylab = "Accuracy")
abline(h = baseline["accuracy"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)

plot(x = data$nRules, y = 1 - data$hamming, col = data$reg, 
     ylim = range(c(1 - data$hamming, 1 - baseline["hamming"])),
     xlab = "Number of Rules", ylab = "Hamming Accuracy")
abline(h = 1 - baseline["hamming"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)

plot(x = data$nRules, y = data$logLoss, col = data$reg, 
     ylim = range(c(data$logLoss, baseline["logLoss"])),
     xlab = "Number of Rules", ylab = "log Likelihood")
abline(h = baseline["logLoss"], lty = 2,  col = 4)
legend("bottomright", legend = c("Hard Regularizer", "Adaptive Regularizer", "Base classifier"),
       col = c(1, 2, 4), pch = 1)
dev.off()
# That's not good.

