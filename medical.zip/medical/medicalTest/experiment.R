# Get the ID that SLURM hands over to the script as argument
folds <- as.integer(Sys.getenv("PBS_ARRAYID"))
if(is.na(folds)){
  folds <- 1:5
}
cat("ID = ", paste(folds, collapse = ", "), "\n")

todo <- expand.grid(rules = c(50, 75, 100, 125), folds = 1, it = 1:3)
fold <- todo[folds, "folds"]
nRules <- todo[folds, "rules"]
it <- todo[folds, "it"]

# Dependencies:
library("parallel")
source("rsl.R")
library(microbenchmark)

# And the simData_k.RData have to be located in the directory

# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual, cl = NULL){
  # cat("Predicting on train...\n")
  # predTrainMarg <- predict(rsl, train)
  # logLTrainMarg <- mean(.labelwiseLogLikelihood(predTrainMarg, trainActual))
  # predTrainMarg <- .probabilisticToCrispData(rsl, predTrainMarg)
  # accTrainMarg <- accuracy(predTrainMarg, trainActual)
  # hamTrainMarg <- hammingLoss(predTrainMarg, trainActual)
  # # likTrainMarg <- .avgLogLikelihood(rsl, train, trainActual)
  # likTrainMarg <- NA
  # # cat("Predicting train2...\n")
  # try({predTrainJoint <- predict(rsl, train, type = "joint", method = "approximate")
  # predTrainJoint <- .probabilisticToCrispData(rsl, predTrainJoint)
  # accTrainJoint <- accuracy(predTrainJoint, trainActual)})
  
  cat("Predicting on val...\n")
  predValMarg <- predict(rsl, val, cluster = cl)
  logLValMarg <- median(.labelwiseLogLikelihood(predValMarg, valActual))
  predValMargCrisp <- .probabilisticToCrispData(rsl, predValMarg)
  accValMarg <- accuracy(predValMargCrisp, valActual)
  hamValMarg <- hammingLoss(predValMargCrisp, valActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, valActual, cluster = cl)
  likValMarg <- NA
  try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate", cluster = cl)
  predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  accValJoint <- accuracy(predValJointCrisp, valActual)})
  
  # cat("Predicting on test...\n")
  # predTime <- microbenchmark(predTestMarg <- predict(rsl, test), times = 1)$time / nrow(test)
  # logLTestMarg <- mean(.labelwiseLogLikelihood(predTestMarg, testActual))
  # predTestMarg <- .probabilisticToCrispData(rsl, predTestMarg)
  # accTestMarg <- accuracy(predTestMarg, testActual)
  # hamTestMarg <- hammingLoss(predTestMarg, testActual)
  # # likTestMarg <- .avgLogLikelihood(rsl, test, testActual)
  # likTestMarg <- NA
  # try({predTestJoint <- predict(rsl, test, type = "joint", method = "approximate")
  # predTestJoint <- .probabilisticToCrispData(rsl, predTestJoint)
  # accTestJoint <- accuracy(predTestJoint, testActual)})
  
  return(list(#accTrain = accTrainMarg, hamTrain = hamTrainMarg, logLikTrain = likTrainMarg, labelwiseLogLTrain = logLTrainMarg, accTrainMPE = accTrainJoint,
    accVal = accValMarg, hamVal = hamValMarg, logLikVal = likValMarg, labelwiseLogLVal = logLValMarg, accValMPE = accValJoint, predValMarg = predValMarg, predValJoint = predValJoint))#,
  # accTest = accTestMarg, hamTest = hamTestMarg, logLikTest = likTestMarg, labelwiseLogLTest = logLTestMarg, accTestMPE = accTestJoint,
  # avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

# Initialize cluster

ntasks <- 10
cl <- makeCluster(ntasks)
clusterSetRNGStream(cl, iseed=22122020 + it - 1)
set.seed(22122020 + it - 1)
clusterEvalQ(cl, source("rsl.R"))

# Main:
# Learn an rsl
# load an object called data containing all important data
load(paste0("../data/data_", fold, ".RData"))
cat(fold, ":", nRules, "\n")
rsl <- .buildRSL(data$labels, list())
# Change colnames of xyzActual stuff
colnames(data$trainActual) <- .getAllLabelNodes(rsl)
colnames(data$valActual) <- .getAllLabelNodes(rsl)
colnames(data$testActual) <- .getAllLabelNodes(rsl)
rsl <- learnRules(rsl, data$train, data$trainActual, nRules = nRules,
                  method = "noisyor", batchsize = 20, reg = "beta", lambda = 5, maxIter = 10,
                  maxLabelsPerRule = 5, alphaReg = 0.025, betaReg = 0.5, regDecay = 0.98, cluster = cl)

# evaluate and save
save(rsl, file = paste0(fold, "_", nRules, "_", it, "_rsl.RData"))
clusterSetRNGStream(cl, iseed=22122020 + it - 1)
set.seed(22122020 + it - 1)
res <- .evalPerformance(rsl, data$train, data$trainActual,
                        data$val, data$valActual,
                        data$test, data$testActual, cl = cl)
save(res, file = paste0(fold, "_", nRules, "_", it, "_res.RData"))

# stop cluster
stopCluster(cl)
