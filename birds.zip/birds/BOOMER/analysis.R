# Read in and evaluate performance of the MLWSE predictions

source("rsl.R")

.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}

f1macro <- function(pred, actual){
  f1 <- numeric(ncol(actual))
  for(i in seq(along = f1)){
    trueClass <- paste0(colnames(actual)[i], "_1")
    pr <- sum(pred[, i] == trueClass & actual[, i] == trueClass) / 
      sum(pred[, i] == trueClass)
    rc <- sum(pred[, i] == trueClass & actual[, i] == trueClass) /
      sum(actual[, i] == trueClass)
    f1[i] <- 2 * pr * rc / (pr + rc)
  }
  
  return(mean(f1))
}

# Summarize the raw test outputs into metrics (create the res_i.RData)
set.seed(25112020)
for(i in 1:10){
  load(paste0("../data/data_", i,".RData"))
  rsl <- .buildRSL(data$labels, NULL)
  
  # Read and preprocess the predictions on the test data
  pred <- read.csv(paste0("./", i, "/pred.csv"), header = TRUE)
  # Remove ground truth labels
  pred <- pred[, (ncol(pred)/2 + 1):ncol(pred)]
  colnames(pred) <- colnames(data$test)
  pred0 <- 1 - pred
  colnames(pred0) <- gsub("_1$", "_0", colnames(pred0))
  pred <- cbind(pred, pred0)
  pred <- as.data.frame(pred)
  
  # Compute all values of interest
  logLMarg <- median(.labelwiseLogLikelihood(pred, data$testActual))
  predMargCrisp <- .probabilisticToCrispData(rsl, pred)
  colnames(predMargCrisp) <- colnames(data$testActual)
  accMarg <- accuracy(predMargCrisp, data$testActual)
  hamTestMarg <- hammingLoss(predMargCrisp, data$testActual)
  f1 <- f1macro(pred, data$testActual)
  # likValMarg <- .avgLogLikelihood(rsl, val, data$testActual)
  # likValMarg <- NA
  # try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  # predValJointCrisp <- .probabilisticToCrispData(rsl, predValJoint)
  # accValJoint <- accuracy(predValJointCrisp, data$testActual)})
  
  res <- list(logLikTest = logLMarg, hamTest = hamTestMarg, accTest = accMarg, f1Test = f1)
  save(res, file = paste0(i, "_res.RData"))
}

# summarize across folds
allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#       logLikTest    hamTest   accTest f1Test
#  [1,]      -11.5 0.04111842 0.5000000    NaN
#  [2,]      -23.0 0.04523026 0.4843750    NaN
#  [3,]      -23.0 0.04194079 0.4375000    NaN
#  [4,]        0.0 0.04440789 0.5156250    NaN
#  [5,]        0.0 0.04276316 0.5937500    NaN
#  [6,]        0.0 0.04129555 0.5538462    NaN
#  [7,]        0.0 0.04129555 0.5846154    NaN
#  [8,]      -23.0 0.04534413 0.4769231    NaN
#  [9,]        0.0 0.03481781 0.5538462    NaN
# [10,]        0.0 0.03643725 0.5692308    NaN

nFolds <- nrow(allData)
apply(allData, 2, mean)
#  logLikTest     hamTest     accTest      f1Test 
# -8.05000000  0.04146508  0.52697115         NaN 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#  logLikTest     hamTest     accTest      f1Test 
# 9.818872135 0.003138379 0.046662477          NA 