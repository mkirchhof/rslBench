# Evaluates the performance of the baseline classifiers without any rsl


# Dependencies:
source("rsl.R")
library(microbenchmark)


# evalPerformance - evaluates hamming loss, accuracy and log-likelihood on 
#                   test, validation and train data and the time it took per 
#                   sample for a prediction on the test dataset
.evalPerformance <- function(rsl, train, trainActual, val, valActual, test, testActual){
  cat("Predicting on train...\n")
  predTrainMarg <- predict(rsl, train)
  logLTrainMarg <- median(.labelwiseLogLikelihood(predTrainMarg, trainActual))
  predTrainMarg <- .probabilisticToCrispData(rsl, predTrainMarg)
  accTrainMarg <- accuracy(predTrainMarg, trainActual)
  hamTrainMarg <- hammingLoss(predTrainMarg, trainActual)
  likTrainMarg <- .avgLogLikelihood(rsl, train, trainActual)
  #likTrainMarg <- NA
  try({predTrainJoint <- predict(rsl, train, type = "joint", method = "approximate")
  predTrainJoint <- .probabilisticToCrispData(rsl, predTrainJoint)
  accTrainJoint <- accuracy(predTrainJoint, trainActual)})
  
  cat("Predicting on val...\n")
  predValMarg <- predict(rsl, val)
  logLValMarg <- median(.labelwiseLogLikelihood(predValMarg, valActual))
  predValMarg <- .probabilisticToCrispData(rsl, predValMarg)
  accValMarg <- accuracy(predValMarg, valActual)
  hamValMarg <- hammingLoss(predValMarg, valActual)
  likValMarg <- .avgLogLikelihood(rsl, val, valActual)
  #likValMarg <- NA
  try({predValJoint <- predict(rsl, val, type = "joint", method = "approximate")
  predValJoint <- .probabilisticToCrispData(rsl, predValJoint)
  accValJoint <- accuracy(predValJoint, valActual)})
  
  cat("Predicting on test...\n")
  predTime <- microbenchmark(predTestMarg <- predict(rsl, test), times = 1)$time / nrow(test)
  logLTestMarg <- median(.labelwiseLogLikelihood(predTestMarg, testActual))
  predTestMarg <- .probabilisticToCrispData(rsl, predTestMarg)
  accTestMarg <- accuracy(predTestMarg, testActual)
  hamTestMarg <- hammingLoss(predTestMarg, testActual)
  likTestMarg <- .avgLogLikelihood(rsl, test, testActual)
  # likTestMarg <- NA
  try({predTestJoint <- predict(rsl, test, type = "joint", method = "approximate")
  predTestJoint <- .probabilisticToCrispData(rsl, predTestJoint)
  accTestJoint <- accuracy(predTestJoint, testActual)})
  
  return(list(accTrain = accTrainMarg, hamTrain = hamTrainMarg, logLikTrain = likTrainMarg, labelwiseLogLTrain = logLTrainMarg, accTrainMPE = accTrainJoint,
              accVal = accValMarg, hamVal = hamValMarg, logLikVal = likValMarg, labelwiseLogLVal = logLValMarg, accValMPE = accValJoint,
              accTest = accTestMarg, hamTest = hamTestMarg, logLikTest = likTestMarg, labelwiseLogLTest = logLTestMarg, accTestMPE = accTestJoint,
              avgPredTime = predTime))
}


# .buildRSL - builds an rsl given a ruleset and a labelset
.buildRSL <- function(labels, rules){
  rsl <- createRSL()
  for(i in seq(along = labels)){
    rsl <- addClassifier(rsl, names(labels)[i], labels[[i]], accuracy = 1)
  }
  for(i in seq(along = rules)){
    probs <- rules[[i]]$p
    names(probs) <- rules[[i]]$labels
    rsl <- .addNoisyOR(rsl, probs)
  }
  
  return(rsl)
}


set.seed(25112020)
for(i in 1:10){
  cat(i, "...\n")
  load(paste0("../data/data_", i, ".RData"))
  
  rsl <- .buildRSL(data$labels, list())
  # Change colnames of xyzActual stuff
  colnames(data$trainActual) <- .getAllLabelNodes(rsl)
  colnames(data$valActual) <- .getAllLabelNodes(rsl)
  colnames(data$testActual) <- .getAllLabelNodes(rsl)
  
  res <- .evalPerformance(rsl, data$train, data$trainActual,
                          data$val, data$valActual,
                          data$test, data$testActual)
  save(res, file = paste0(i, "_res.RData"))
}


allRes <- list()
for(nRules in seq(1, 10, by = 1)){
  cat(nRules, ":\n")
  load(paste0(nRules, "_res.RData"))
  allRes[[nRules]] <- res
}

allData <- matrix(unlist(allRes), nrow = 10, byrow = TRUE)
colnames(allData) <- names(res)

#        accTrain   hamTrain logLikTrain labelwiseLogLTrain accTrainMPE   accVal     hamVal logLikVal labelwiseLogLVal accValMPE   accTest    hamTest logLikTest labelwiseLogLTest accTestMPE avgPredTime
#  [1,] 0.5319149 0.04143337   -2.488430          -1.694476   0.5319149 0.437500 0.04523026 -2.808122        -2.269820  0.437500 0.4843750 0.04523026  -2.879007         -1.966926  0.4843750     4847244
#  [2,] 0.5106383 0.04296040   -2.620921          -1.850030   0.5106383 0.531250 0.03947368 -2.565448        -1.643187  0.531250 0.5312500 0.03865132  -2.397530         -1.693137  0.5312500     4829302
#  [3,] 0.5261122 0.04194238   -2.492312          -1.710917   0.5261122 0.468750 0.04851974 -2.769805        -2.038182  0.468750 0.4375000 0.04194079  -2.517470         -1.884651  0.4375000     4847273
#  [4,] 0.5067698 0.04357121   -2.666927          -1.769788   0.5067698 0.546875 0.04194079 -2.155773        -1.885250  0.546875 0.5000000 0.04276316  -2.356025         -1.983254  0.5000000     4846584
#  [5,] 0.5164410 0.04143337   -2.459633          -1.793527   0.5164410 0.468750 0.04687500 -2.871309        -2.299704  0.468750 0.5468750 0.04358553  -2.553496         -1.444483  0.5468750     4912619
#  [6,] 0.5116279 0.04273766   -2.549267          -1.901569   0.5116279 0.562500 0.04194079 -2.445761        -1.710782  0.562500 0.5692308 0.03967611  -2.472502         -1.615472  0.5692308     5251658
#  [7,] 0.4980620 0.04345165   -2.504895          -1.960104   0.4980620 0.578125 0.03371711 -2.088250        -1.503877  0.578125 0.5384615 0.03967611  -2.387264         -1.525982  0.5384615     4816811
#  [8,] 0.5213178 0.04120767   -2.601556          -1.740095   0.5213178 0.500000 0.04440789 -2.561435        -1.888736  0.500000 0.4307692 0.04777328  -2.299874         -2.061158  0.4307692     4842466
#  [9,] 0.5213178 0.04263566   -2.529480          -1.802889   0.5213178 0.453125 0.03947368 -2.202846        -2.180583  0.453125 0.5384615 0.04129555  -2.363949         -1.168046  0.5384615     4839009
# [10,] 0.5116279 0.04334965   -2.594950          -1.757008   0.5116279 0.515625 0.04029605 -2.716641        -1.905534  0.515625 0.5230769 0.04048583  -2.252563         -1.807349  0.5230769     4855186

nFolds <- nrow(allData)
apply(allData, 2, mean)
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal 
# 5.155830e-01       4.247230e-02      -2.550837e+00      -1.798040e+00       5.155830e-01       5.062500e-01       4.218750e-02      -2.518539e+00 
# labelwiseLogLVal          accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
#    -1.932566e+00       5.062500e-01       5.100000e-01       4.210779e-02      -2.447968e+00      -1.715046e+00       5.100000e-01       4.888815e+06 
apply(allData, 2, sd) * (nFolds - 1) / nFolds
#     accTrain           hamTrain        logLikTrain labelwiseLogLTrain        accTrainMPE             accVal             hamVal          logLikVal 
# 8.922162e-03       8.111479e-04       6.082989e-02       7.582662e-02       8.922162e-03       4.357106e-02       3.870290e-03       2.574467e-01 
# labelwiseLogLVal          accValMPE            accTest            hamTest         logLikTest  labelwiseLogLTest         accTestMPE        avgPredTime 
#     2.405227e-01       4.357106e-02       4.178639e-02       2.537662e-03       1.599369e-01       2.529646e-01       4.178639e-02       1.169406e+05 