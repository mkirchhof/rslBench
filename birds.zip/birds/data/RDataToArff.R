# writeArff is an adaption of the mldr::write_arff. The mldr version expects a
# mldr object, but we just want to give a dataframe
writeArff <- function(x, y, filename){
  con <- file(paste0(filename, ".arff"))
  
  header <- paste0("@relation ", filename)
  
  attr <- paste0("@attribute ", colnames(x), " numeric")
  attr <- c(attr, paste0("@attribute ", colnames(y), " {0,1}"))
  
  data <- cbind(x, y)
  data <- apply(data, 1, function(c) paste(c, collapse = ','))
  
  # Write header, attributes and data
  writeLines(c(header, "", attr, "", "@data", data), con)
  close(con)
  
  con <- file(paste0(filename, ".xml"))
  xmlheader <- '<?xml version="1.0" encoding="utf-8"?>'
  labelstag <- '<labels xmlns="http://mulan.sourceforge.net/labels">'
  labeltags <- paste(c('<label name="'), colnames(y), c('"></label>'), sep = "")
  labelsend <- '</labels>'
  
  writeLines(c(xmlheader, labelstag, labeltags, labelsend), con)
  close(con)
}

for(i in 1:10){
  train <- read.csv(paste0("trainXWithoutVal_", i,".csv"))
  trainActual <- read.csv(paste0("trainYWithoutVal_", i,".csv"))
  val <- read.csv(paste0("trainXVal_", i,".csv"))
  valActual <- read.csv(paste0("trainYVal_", i,".csv"))
  test  <- read.csv(paste0("testX_", i,".csv"))
  testActual <- trainActual[1:nrow(test), ] # Give fake ground-truth on test data
  # So that the external algorithms cannot cheat
  
  writeArff(train, trainActual, paste0("train_", i))
  writeArff(val, valActual, paste0("val_", i))
  writeArff(test, testActual, paste0("test_", i))
}